import { run } from "./main";

export function pong() {
  run('canvas');
}